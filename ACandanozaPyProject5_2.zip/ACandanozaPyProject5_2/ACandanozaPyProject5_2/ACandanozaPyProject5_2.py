import folium
import webbrowser

map1 = folium.Map(location =[26.19, -97.69], zoom_start = 12)
folium.CircleMarker(location =[26.19, -97.69], radius = 300, popup = "HARLINGEN").add_to(map1)

map2= folium.Map(location =[26.19, -97.69], zoom_start = 12)
folium.Marker(location =[26.19, -97.69], popup = "HARLINGEN").add_to(map1)

map3 = folium.Map(location =[31.64, -97.08], zoom_start = 12)
folium.CircleMarker(location =[31.64, -97.08], radius = 20, popup = "TSTC WACO").add_to(map1)

map4 = folium.Map(location =[31.64, -97.08], zoom_start = 12)
folium.Marker(location =[31.64, -97.08], popup = "TSTC WACO").add_to(map1)

map5 = folium.Map(location =[26.22, -97.67], zoom_start = 12)
folium.Marker(location =[26.22, -97.67], popup = "TSTC HARLINGEN").add_to(map1)

map6 = folium.Map(location =[30.27, -97.74], zoom_start = 12)
folium.Marker(location =[30.27, -97.74], popup = "Austin State Capitol Building").add_to(map1)


folium.PolyLine(locations = [(31.64, -97.08), (26.19, -97.69), (30.27, -97.74), (26.22, -97.67)], line_opacity = .6).add_to(map1)
map1.save("project.html")
#open in browser
webbrowser.open("project.html")
