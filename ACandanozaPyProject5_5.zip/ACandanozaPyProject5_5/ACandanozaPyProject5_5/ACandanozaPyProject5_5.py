import sqlite3 as sl

con = sl.connect('movies.db')

c = con.cursor()

c.execute('''SELECT count(name) FROM sqlite_master WHERE type='table' AND name='MOVIES' ''')


if c.fetchone()[0]==1 :
    print('Table Exists.')
else :
    print('Table does not exists.')

    with con:
        con.execute("""
            CREATE TABLE MOVIES (
                id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                genre TEXT,
                releaseDate INTEGER
             );
         """)

    sql = 'INSERT INTO MOVIES (id, name, genre, releaseDate) values(?, ?, ?, ?)'
    data = [
       (1, 'Aliens', 'Action', 1989),
       (2, 'Predator', 'Horror', 1999),
       (3, 'Alien: Covenant', 'Horror', 2016),
       (4, 'Alien Resurrection', 'Action', 2000),
       (5, 'Prometheus', 'Horror', 2013),
       (6, 'Norbit', 'Funny', 2001),
       (7, 'Alien', 'Horror', 1976)
       (8, 'Avengers', 'Action', 2014)
       (9, 'Godzilla', 'Action', 2014)
       (10, 'Frozen', 'Fantasy', 2012)

    ]

    with con:
        con.executemany(sql, data)

with con:
    data = con.execute("SELECT * FROM MOVIES WHERE releaseDate < 2000")
    for row in data:
        print(row)

with con:
    data = con.execute("SELECT * FROM MOVIES WHERE releaseDate > 2000")
    for row in data:
        print(row)
